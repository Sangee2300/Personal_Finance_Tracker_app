document.addEventListener('DOMContentLoaded', () => {
    const addTransactionBtn = document.getElementById('addTransactionBtn');
    const transactionList = document.getElementById('transactionList');
    const totalIncome = document.getElementById('totalIncome'); 
    const totalExpenses = document.getElementById('totalExpenses');
    const balance = document.getElementById('balance'); 

    // Display Transactions Function
    function displayTransactions() {
        const transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        transactionList.innerHTML = '';

        transactions.forEach((transaction, index) => {
            const li = document.createElement('li');

            if (transaction.category === 'Income') {
                li.innerHTML = `
                    ${transaction.name} - $${transaction.amount.toFixed(2)} (${transaction.category})
                    <button class='delete-btn' onclick='deleteTransaction(${index})'>Delete</button>
                `;
                li.style.backgroundColor = '#0e3a0f';
                li.style.color = 'white';
            } else {
                li.innerHTML = `
                    ${transaction.name} - $${transaction.amount.toFixed(2)} (${transaction.category})
                    <button class='delete-btn' onclick='deleteTransaction(${index})'>Delete</button>
                `;
                li.style.backgroundColor = '#705814';
                li.style.color = 'white';
            }

            transactionList.appendChild(li);
        });
    }

    // Add Transaction Button Event Listener
    addTransactionBtn.addEventListener('click', addTransaction);

    // Add Transaction Function
    function addTransaction() {
        const name = document.getElementById('transactionName').value;
        const amount = parseFloat(document.getElementById('transactionAmount').value);
        const category = document.getElementById('transactionCategory').value;

        if (name && !isNaN(amount)) {
            const transactions = JSON.parse(localStorage.getItem('transactions')) || [];
            const newTransaction = { name, amount, category };
            transactions.push(newTransaction);
            localStorage.setItem('transactions', JSON.stringify(transactions));
            displayTransactions();
            updateSummary();
        }
    }

    // Update Summary Function
    function updateSummary() {
        const transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        let totalIncomeAmount = 0;
        let totalExpensesAmount = 0;

        transactions.forEach((transaction) => {
            if (transaction.category === 'Income') {
                totalIncomeAmount += transaction.amount;
            } else {
                totalExpensesAmount += transaction.amount;
            }
        });

        const balanceAmount = totalIncomeAmount - totalExpensesAmount;

        // Update the text content of the DOM elements
        totalIncome.textContent = totalIncomeAmount.toFixed(2);
        totalExpenses.textContent = totalExpensesAmount.toFixed(2);
        balance.textContent = balanceAmount.toFixed(2);
    }

    // Delete Transaction Function
    function deleteTransaction(index) {
        const transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        transactions.splice(index, 1);
        localStorage.setItem('transactions', JSON.stringify(transactions));
        displayTransactions();
        updateSummary();
    }

    // Expose deleteTransaction to global scope
    window.deleteTransaction = deleteTransaction;

    // Initial load
    displayTransactions();
    updateSummary();
});
